import React from 'react';
declare const Emoji: React.MemoExoticComponent<({ name }: {
    name: string;
}) => JSX.Element>;
export { Emoji };
