import React from 'react';
import { TextProps } from 'react-native';
export declare const CountryText: (props: TextProps & {
    children: React.ReactNode;
}) => JSX.Element;
