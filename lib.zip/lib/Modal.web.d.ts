import Modal from 'modal-react-native-web';
export { Modal };
