export declare const getHeightPercent: (percentage: number) => number;
